# Fork of leaflet-shiny 


Original repos : <https://github.com/jcheng5/leaflet-shiny/>


# Modifications :
- Added imageOverlay layers.
