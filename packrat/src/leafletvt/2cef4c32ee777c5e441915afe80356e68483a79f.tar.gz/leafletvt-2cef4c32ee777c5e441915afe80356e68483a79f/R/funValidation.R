

#' Check for no null, NA's, nchar of 0, lenght of 0  or "[NO DATA]" string in a vector.
#' @param val  Vector to test for no data.
#' @return TRUE if no data (nchar == 0 OR is.na OR is.null) found or if input is not a vector
#' @export
noDataCheck<-function(val){
  #if(!is.vector(val)) stop(paste("val should be a vector. Provided value=",typeof(val)))
  if(!is.vector(val)){
    return(TRUE)
  }
  noData = isTRUE("[NO DATA]" %in% val)
  any(c(isTRUE(is.null(val)),isTRUE(is.na(val)),isTRUE(nchar(val)==0),isTRUE(length(val)==0),noData))
}


