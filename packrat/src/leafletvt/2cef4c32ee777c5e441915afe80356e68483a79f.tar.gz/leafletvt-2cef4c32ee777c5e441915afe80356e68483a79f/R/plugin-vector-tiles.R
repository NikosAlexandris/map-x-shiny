leafletVectorTilesDependencies <- function() {
  list(
 #   htmltools::htmlDependency(
 #     "data-textures",
 #     "0.0",
 #     system.file("plugin/textures/",package="leafletvt"),
 #     script= "textures.min.js"
 #     ),
    htmltools::htmlDependency(
      "leaflet-vector-tiles-lib",
      "0.1.5",
      system.file("plugin/leaflet-vector-tiles/lib/dist/", package = "leafletvt"),
      #script = "Leaflet.MapboxVectorTile.min.js"
      script = "Leaflet.MapboxVectorTile.js"
    ),
    htmltools::htmlDependency(
      "leaflet-vector-tiles-binding",
      packageVersion("leafletvt"),
      system.file("plugin/leaflet-vector-tiles/binding/", package = "leafletvt"),
      script = "leaflet-vector-tiles-plugin.js"
    )
  )
}




#' Add vector tiles for a given PGRestAPI postgres endpoint.
#' @param map Leaflet map object
#' @param urlTemplate Url template for a given PGRestAPI endpoint.
#' @export
addVectorTiles <- function(
  map,
  url="localhost",
  port=3030,
  table=NULL,
  dataColumns=NULL,
  geomColumn="geom", # should be auto resolved by PGRestAPI
  idColumn="gid", # should be auto resolved by PGRrestAPI
  id = NULL,
  group="default",
  debug=FALSE,
  zIndex =100
) {
  layer <- paste0(table,"_",geomColumn)
  cols <- unique(c(idColumn,dataColumns))
  cols <- cols[!cols %in% "geom"]
  cols <- sprintf("?fields=%s",paste(cols,collapse=",")) 
  url <- sprintf("http://%s:%s/services/postgis/%s/%s/vector-tiles/{z}/{x}/{y}.pbf%s",url,port,table,geomColumn,cols)
  map$dependencies <- c(map$dependencies, leafletVectorTilesDependencies())
  options = list(debug=debug,zIndex=zIndex)
  invokeMethod(map,getMapData(map),'addVectorTiles',url,layer,idColumn,id,group,options)
}


#' Remove vector tiles.
#' @param map Leaflet map object
#' @param group Group/id of the vector tiles layer
#' @export
setVectorTilesVisibility <- function(
  map,
  group="default",
  visible=TRUE
) {
  map$dependencies <- c(map$dependencies, leafletVectorTilesDependencies())
  invokeMethod(map,getMapData(map),'setVectorTilesVisibility',as.character(group))
}




#
#providerTileOptions <- function(errorTileUrl = '', noWrap = FALSE,
#  opacity = NULL, zIndex = NULL, unloadInvisibleTiles = NULL,
#  updateWhenIdle = NULL, detectRetina = FALSE, reuseTiles = FALSE, ...
#) {
#  opts <- list(errorTileUrl = errorTileUrl, noWrap = noWrap,
#    zIndex = zIndex, unloadInvisibleTiles = unloadInvisibleTiles,
#    updateWhenIdle = updateWhenIdle, detectRetina = detectRetina,
#    reuseTiles = reuseTiles, ...)
#  # Don't include opacity=NULL--it overrides the provider's default opacity
#  if (!is.null(opacity))
#    opts$opacity <- opacity
#  opts
#}


#'@export
setZoom = function(map, zoom, options = list()) {
  view = list(zoom, options)
  dispatch(map,
    "setZoom",
    leaflet = {
      map$x$setZoom = view
      map$x$fitBounds = NULL
      map
    },
    leaflet_proxy = {
      leaflet:::invokeRemote(map, "setZoom", view)
      map
    }
    )
}
