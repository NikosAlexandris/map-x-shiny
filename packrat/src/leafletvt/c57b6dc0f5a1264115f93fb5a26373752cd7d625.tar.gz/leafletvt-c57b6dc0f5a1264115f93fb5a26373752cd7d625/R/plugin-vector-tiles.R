leafletVectorTilesDependencies <- function() {
  ## in a function : call to htmlDependency in run time, not build time
  list(
    htmltools::htmlDependency(
      name = "leaflet-mapbox-gl",
      version = "0.0.1",
      src = system.file("plugin/leaflet-vector-tiles/mapbox-gl/", package = "leafletvt"),
      script = "leaflet-mapbox-gl.js"
      ),
    htmltools::htmlDependency(
      name = "mapbox-gl",
      version = "0.12.3",
      src = system.file("plugin/leaflet-vector-tiles/mapbox-gl/", package = "leafletvt"),
      stylesheet = "mapbox-gl.css",
      script = "mapbox-gl.js"
      ),
    htmltools::htmlDependency(
      name = "leaflet-vector-tiles-lib",
      version = "0.1.7",
      src = system.file("plugin/leaflet-vector-tiles/lib_new/dist/", package = "leafletvt"),
      script = "Leaflet.MapboxVectorTile.js"
      ),
    htmltools::htmlDependency(
      name = "leaflet-vector-tiles-binding",
      version = packageVersion("leafletvt"),
      src = system.file("plugin/leaflet-vector-tiles/binding/", package = "leafletvt"),
      script = "leaflet-vector-tiles-plugin.js"
      )
    )
}



#' Add mapbox gl layer
#' @export
addGlLayer <- function(
  map,
  styleId=NULL,
  token=NULL,
  id=NULL){
  map$dependencies <- c(map$dependencies, leafletVectorTilesDependencies())

  invokeMethod(map,getMapData(map),'addGlLayer',styleId,token,id)
}
  

#' Add vector tiles for a given PGRestAPI postgres endpoint.
#' @param map Leaflet map object
#' @param urlTemplate Url template for a given PGRestAPI endpoint.
#' @export
addVectorTiles <- function(
  map,
  url="localhost",
  port=3030,
  table=NULL,
  dataColumns=NULL,
  geomColumn="geom", # should be auto resolved by PGRestAPI
  idColumn="gid", # should be auto resolved by PGRrestAPI
  id = NULL,
  group="default",
  debug=FALSE,
  zIndex =100,
  onLoadFeedback=c('once','never','always')
) {
  onLoadFeedback <- match.arg(onLoadFeedback)
  layer <- paste0(table,"_",geomColumn)
  cols <- unique(c(idColumn,dataColumns))
  cols <- cols[!cols %in% "geom"]
  cols <- sprintf("?fields=%s",paste(cols,collapse=",")) 
  url <- sprintf("http://%s:%s/services/postgis/%s/%s/vector-tiles/{z}/{x}/{y}.pbf%s",url,port,table,geomColumn,cols)
  map$dependencies <- c(map$dependencies, leafletVectorTilesDependencies())
  options = list(
    debug=debug,
    zIndex=zIndex,
    onLoadFeedback=onLoadFeedback
    )
  invokeMethod(map,getMapData(map),'addVectorTiles',url,layer,idColumn,id,group,options)
}

#' Add vector base map
#' @export
addVectorBase <- function(map,layerId){ 
  map$dependencies <- c(map$dependencies, leafletVectorTilesDependencies())
  invokeMethod(map,getMapData(map),'addVectorBase',layerId)
}

#' Add vector country map
#' @export
addVectorCountries <- function(
  map,
  url="localhost",
  port=3030,
  table=NULL,
  iso3column=NULL,
  iso3select="COD",
  geomColumn="geom", # should be auto resolved by PGRestAPI
  idColumn="gid", # should be auto resolved by PGRrestAPI
  id = NULL
  ){ 
  
  map$dependencies <- c(map$dependencies, leafletVectorTilesDependencies())
  idLayer <- id
  layer <- paste0(table,"_",geomColumn) 
  cols <- sprintf("?fields=%s",iso3column) 
  url <- sprintf("http://%s:%s/services/postgis/%s/%s/vector-tiles/{z}/{x}/{y}.pbf%s",
    url,
    port,
    table,
    geomColumn,
    cols)


  invokeMethod(map,getMapData(map),'addVectorCountries',url,layer,idColumn,idLayer,iso3column,iso3select)
}

#' Remove vector tiles.
#' @param map Leaflet map object
#' @param group Group/id of the vector tiles layer
#' @export
setVectorTilesVisibility <- function(
  map,
  group="default",
  visible=TRUE
) {
  map$dependencies <- c(map$dependencies, leafletVectorTilesDependencies())
  invokeMethod(map,getMapData(map),'setVectorTilesVisibility',as.character(group))
}




#
#providerTileOptions <- function(errorTileUrl = '', noWrap = FALSE,
#  opacity = NULL, zIndex = NULL, unloadInvisibleTiles = NULL,
#  updateWhenIdle = NULL, detectRetina = FALSE, reuseTiles = FALSE, ...
#) {
#  opts <- list(errorTileUrl = errorTileUrl, noWrap = noWrap,
#    zIndex = zIndex, unloadInvisibleTiles = unloadInvisibleTiles,
#    updateWhenIdle = updateWhenIdle, detectRetina = detectRetina,
#    reuseTiles = reuseTiles, ...)
#  # Don't include opacity=NULL--it overrides the provider's default opacity
#  if (!is.null(opacity))
#    opts$opacity <- opacity
#  opts
#}


#'@export
setZoom = function(map, zoom, options = list()) {
  view = list(zoom, options)
  dispatch(map,
    "setZoom",
    leaflet = {
      map$x$setZoom = view
      map$x$fitBounds = NULL
      map
    },
    leaflet_proxy = {
      leaflet:::invokeRemote(map, "setZoom", view)
      map
    }
    )
}
