

#' Check for no data.
#' @return TRUE if no data (nchar == 0 OR is.na OR is.null) found or if input is not a vector
#' @param val  Vector to test for no data.
#' @export
noDataCheck<-function(val){
  if(!is.vector(val)) return(TRUE)
  any(c(isTRUE(is.null(val)),isTRUE(is.na(val)),isTRUE(nchar(val)==0)))
}


