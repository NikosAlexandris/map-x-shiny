

#' Get vector tile layer (PostGIS table) from PGRestAPI
#' @param url Server url (without http://), default = "localhost".
#' @param port Server port number, default = 3000
#' @export
vtGetLayers<-function(url="localhost",port=3030,grepExpr="",nTry=5){
  nTryOrig = nTry
  
  urlFetch <- sprintf("http://%s:%s/services/tables?format=json",url,port)
  
  vt = character(0)

  layerFetched <- FALSE

  for(i in 1:nTryOrig){
    if(!layerFetched){
      tryCatch({
        vt = jsonlite::fromJSON(urlFetch)
        layerFetched <- TRUE
      },error=function(e){
        Sys.sleep(i)
        message("error after",i,"tries, reason:",e$message)
      },finally={closeAllConnections()}
      )
    }
  }

  if(nchar(grepExpr)>0) vt <- grep(grepExpr,vt,value=TRUE)
  return(vt)
}

#
#vtGetLayers<-function(url="localhost",port=3030,grepExpr="",nTry=5){
#  nTryOrig = nTry
#  hadError = FALSE
#  urlFetch<-sprintf("http://%s:%s/services/tables?format=json",url,port)
#  vt = character(0)
#
#  tryCatch({
#    vt = jsonlite::fromJSON(urlFetch)
#  },error=function(e){
#    hadError = TRUE
#    if(nTry>=0){
#      message('Error during fetching json in vtGetLayers. Retrying. Retry left=',nTry,"; url=",url)
#      nTry <- nTry-1
#      Sys.sleep(1)
#      vt = vtGetLayers(url,port,grepExpr,nTry)
#      
#      #vt = jsonlite::fromJSON(urlFetch)
#    }else{
#      message(e)
#      stop(paste("vtGetlayer on ",url,"failed after",nTryOrig,"tries."))
#    }
#  }
#    )
#  #if(hadError)browser()
#
#  browser()
#
#
#  if(nchar(grepExpr)>0) vt <- grep(grepExpr,vt,value=TRUE)
#  return(vt)
#}
#

#' Get available fields/columns from a layer/table
#' @param url Server url (without http://), default = "localhost"
#' @param port Server port number, default = 3000
#' @param table Table name.
#' @export
vtGetColumns<-function(url='localhost',port=3030,table=NULL,exclude=NULL){
  if(missing(table))stop('table paramater missing')
  if(isTRUE(nchar(table)<1) || is.null(table)) return()
  url<-sprintf("http://%s:%s/services/tables/%s?format=json",url,port,table)
  res<-jsonlite::fromJSON(url)
  vtEnabled<-isTRUE(grep('Vector Tile Service',res$supportedOperations$name)>0)
  if(!vtEnabled)return()
  res <- res$columns

  if(!is.null(exclude)){
    if(is.vector(exclude))
      res <- res[!res$column_name %in% exclude,]
  }
  return(res)
}

#' Get layer/table and available field/column combined in a list
#' @param url Server url (without http://), default = "localhost"
#' @param port Server port number. default = 3000
vtDataList<-function(url='localhost',port=3030){
  res=list()
  tn<-vtGetLayers(url=url,port=port)
  if(length(tn)<0)return(null)
  for(t in tn){
    cols<-list(vtGetColumns(url=url,port=port,table=t))
    names(cols)<-t
    res<-c(res,cols)
  }
  return(res)
}

