

//
var leafletvtId = {};
//var leafletvtLegends = {};
//var leafletvtVisible = {};
//

hex2rgb = function(hex, opacity) {
  var h=hex.replace("#", "");
  h =  h.match(new RegExp("(.{"+h.length/3+"})", "g"));

  for(var i=0; i<h.length; i++)
    h[i] = parseInt(h[i].length==1? h[i]+h[i]:h[i], 16);

  if (typeof opacity != "undefined")  h.push(opacity);

  return "rgba("+h.join(",")+")" ;
};



//http://stackoverflow.com/questions/5623838/rgb-to-hex-and-hex-to-rgb
/*
   function hexToRgbA(hex,alpha) {
   var bigint = parseInt(hex, 16);
   var r = (bigint >> 16) & 255;
   var g = (bigint >> 8) & 255;
   var b = bigint & 255;

   var col="rgba(" + r + "," + g + "," + b + "," + alpha + ")" ;
   return(col);

   }
   */




var randomHsl = function(opacity) {
  var col = "hsla(" + (Math.random() * 360) + ", 100%, 50%, "+ opacity +")";
  return col;
};

var hexToRgba = function(color, alpha) {

  var r = parseInt(color.substring(1,3),16);
  var g = parseInt(color.substring(3,5),16);
  var b = parseInt(color.substring(5,7),16);
  var a = alpha;

  return "rgba(" + r + "," + g + "," + b + "," + a + ")";

};


var subset = function(object, keys) {
  var tmp = {};
  keys.forEach(function(key) { tmp[key] = object[key]; });
  return tmp;
};



var degreeToRadians = function(degrees) {
  return (degrees * Math.PI / 180);
};

//
//// taken from https://github.com/matthewlein/patternizer.js/blob/master/patternizer.js
var createPattern_orig = function(hatchColor,hatchAngle,hatchWidth,hatchGap) {
  var options = {
    stripes : [ 
    {
      color: hatchColor,
      rotation: hatchAngle,
      opacity: 100,
      mode: "normal",
      width: hatchWidth,
      gap: hatchGap,
      offset: 0
    }
    ],
    bg : "#ffffff"
  };

  var stripes = options.stripes;
  var bgColor = hex2rgb(options.bg,0.2);

  var pattern = document.createElement("canvas");
  //  pattern.className = "pattern-fixed";
  pattern.width = 256;
  pattern.height = 256;
  //var ctx = ctx2d.canvas.getContext("2d");
  var ctx = pattern.getContext("2d");


  //var cWidth = 100;
  var cWidth = ctx.canvas.width;
  //var cHeight = 100;
  var cHeight = ctx.canvas.height;
  var diagLength = Math.sqrt( (cWidth * cWidth) + (cHeight * cHeight) );

  //draw background color
  ctx.fillStyle = bgColor;
  ctx.fillRect( 0, 0, cWidth, cHeight);

  //draw stripes
  for (var j = stripes.length - 1; j >= 0; j--){

    var current = stripes[j],

    opacity = current.opacity / 100 || 0.5,
    color =current.color,
    mode = current.mode || "normal",
    rotate = current.rotation || 0,
    stripeWidth = current.width,
    offset = current.offset || 0,
    gap = current.gap || stripeWidth,

    tile = stripeWidth + gap,
    repeats = ( (diagLength * 2) + offset ) / tile;

    // rotate
    ctx.rotate( degreeToRadians(rotate) );

    for ( var i=0; i < repeats; i++ ) {
      ctx.fillStyle = color;

      // drawing x
      ctx.fillRect( -diagLength + (tile * i) - offset, -diagLength, stripeWidth, diagLength * 2);

      if (mode === "plaid") {

        // drawing y
        ctx.fillRect( -diagLength, -diagLength + (tile * i) - offset, diagLength * 2 , stripeWidth);

      }

    }

    //rotate back
    ctx.rotate( -degreeToRadians(rotate) );
  }


  pattern = ctx.createPattern(pattern, "repeat");

  return(pattern);
};


getDivisorsOf = function(integ){
  // increment from i 0 to integ, divid by i, check if res is integer
  var divisors = [],
  res = 0;
  for(var i = 1; i <= integ; i++){
    res = integ/i;
    if(res === Math.floor(res)){
      divisors.push(i); 
    }
  }
  return divisors;
};


var createPattern = function(hatchColor,hatchAngle,hatchWidth,hatchGap) {

  var options = {
    stripes : [ 
    {
      color: hatchColor,
      rotation: hatchAngle,
      opacity: 100,
      mode: "normal",
      width: hatchWidth,
      gap: hatchGap,
      offset: 0
    }
    ],
    bg : "#ffffff"
  };

  var stripes = options.stripes;
  var bgColor = hex2rgb(options.bg,0.2); 

  //var cWidth = stripes[0].width + stripes[0].gap;
  //var cWidth = ctx.width;
  //var cHeight = stripes[0].width + stripes[0].gap  ;



  var pattern = document.createElement("canvas");
  //  pattern.className = "pattern-fixed";


  cWidth =  (hatchGap + hatchWidth) / Math.sin(degreeToRadians(hatchAngle)) ;
  //  cHeight = pattern.width / Math.tan(Math.PI/2-degreeToRadians(hatchAngle)) ;
  cHeight = pattern.width*Math.abs(Math.tan(degreeToRadians(hatchAngle)));





  pattern.width = cWidth ;
  pattern.height = cHeight; 


  //var ctx = ctx2d.canvas.getContext("2d");
  var ctx = pattern.getContext("2d");



  //var cHeight = ctx.height;
  var diagLength = Math.sqrt( (cWidth * cWidth) + (cHeight * cHeight) );

  //draw background color
  ctx.fillStyle = bgColor;
  ctx.fillRect( 0, 0, cWidth, cHeight);

  //draw stripes
  for (var j = stripes.length - 1; j >= 0; j--){

    var current = stripes[j],

    opacity = current.opacity / 100 || 0.5,
    color =current.color,
    mode = current.mode || "normal",
    rotate = current.rotation || 0,
    stripeWidth = current.width,
    offset = current.offset || 0,
    gap = current.gap || stripeWidth,

    tile = stripeWidth + gap,
    repeats = ( (diagLength * 2) + offset ) / tile;

    // rotate
    ctx.rotate( degreeToRadians(rotate) );

    for ( var i=0; i < repeats; i++ ) {
      ctx.fillStyle = color;

      // drawing x
      ctx.fillRect( -diagLength + (tile * i) - offset, -diagLength, stripeWidth, diagLength * 2);

      if (mode === "plaid") {

        // drawing y
        ctx.fillRect( -diagLength, -diagLength + (tile * i) - offset, diagLength * 2 , stripeWidth);

      }

    }

    //rotate back
    ctx.rotate( -degreeToRadians(rotate) );
  }



  var pattern = ctx.createPattern(pattern, "repeat");
  console.log(pattern) ;
  return pattern ;

};



LeafletWidget.methods.setZoom = function(zoom,options){
  this.setView(this.getCenter(), zoom, options);
};

function objToList(obj,classList,classTitle){
  if(typeof(classList) == "undefined")classList="nav";
  if(typeof(classTitle) == "undefined")classTitle="";
  var html = "<ul class="+classList+">";
  for(var key in obj){
    html += "<li><span class="+classTitle+">"+key+"</span></li>"+obj[key];
  }
  html += "</ul>";
  return html;
}

function objToTable(obj){
  classTable="table"; // boostrap table...
  var html = "<table class="+classTable+"><tr>";
  var key = "";
  for(key in obj){
    if(key !== "gid"){
      html += "<th>"+key+"</th>";
    }
  }
  html += "</tr><tr>";
  for(key in obj){
    if(key !== "gid"){
      html += "<td>"+obj[key]+"</td>";
    }
  }
  html += "</tr></table>";
  return html;
}


// load array content as object key and value..
function toObject(arr) {
  var rv = {};
  for (var i = 0; i < arr.length; ++i)
    rv[arr[i]] = arr[i];
  return rv;
}

LeafletWidget.methods.setVectorTilesVisibility = function(group,visible) {
  var legId = group + "_legends";
  var  g = leafletvtId[group];
  var l = {};
  if(g){
    console.log("group to toggle");
    console.log(group);
    if(visible){
      l = leafletvtLegends[group];
      if(l){
        this.addLayer(l);
      }
      this.addLayer(g);
    }else{
      this.removeLayer(g);
      l = this.getLayer(legId);
      if(l){
        leafletvtLegends[group] = l;
        this.removeLayer(l);
      }
    }
  }
};


LeafletWidget.methods.hideGroup = function(group) {
    var self = this;
    $.each(asArray(group), function(i, g) {
      console.log("hide group" + group);
      var layer = self.layerManager.getLayerGroup(g, true);
      if (layer) {
        self.removeLayer(layer);
      }
    });
  };


LeafletWidget.methods.addVectorTiles = function(urlTemplate,vectLayer,idColumn,layerId,group,options) {



  if(typeof group === "undefined"){
    group="default" ;
  }
  
  if(layerId === null){
    layerId=group ;
  }
  
  if(typeof options.debug == "undefined"){
    debug=false;
  }else{
    debug=options.debug;
  }


// if(typeof leafletvtId[group] == "undefined"){

    //var zIndex = options.zIndex;
    var zIndex = 10;

    var config = {
      url:urlTemplate,
      mutexToggle: true,
      debug: debug,
      clickableLayers: [vectLayer],
      getIDForLayerFeature: function(feature) {
        return feature.properties[idColumn];

      },
      onClick: function(evt) {
        feature = evt.feature;
        coord = evt.latlng;

        Shiny.onInputChange("leafletvtClickCoord",coord);
        if(feature !== null && feature !== undefined){
          featureProp = feature.properties;
          featurePropHtml = objToTable(featureProp);
          $("#info-box-content").html(featurePropHtml);
          Shiny.onInputChange("leafletvtClickProp",featureProp);
        }
      },
      filter: function(feature, context) {
        if (feature.layer.name === vectLayer) {
          return true;
        }
        return false;
      },
      onTilesLoaded: function() {
        var leafletvtStatus = {"lay":vectLayer,"grp":group,"id":layerId};
         console.log("Send status to leaflet vt status. Group= "+group+" Layer= "+ vectLayer);
        Shiny.onInputChange("leafletvtStatus",leafletvtStatus);
      },
      layerOrdering: function(feature) {
        //This only needs to be done for each type, not necessarily for each feature. But we'll start here.
        if (feature && feature.properties) {
          feature.properties.zIndex =  zIndex;
        }
      },
      // DEFAULT STYLE. Will be modified after.
      style: function (feature) {
        var s = {};
        s.color = "rgba(0,0,0,0)";
        return s ;

      }
    };


    var l = new L.TileLayer.MVTSource(config);
    this.layerManager.addLayer(l, "tile", layerId, group); 

    //TODO: avoid this object (used in mxSetStyle) and use the layer manager instead.
    leafletvtId[group] = l;

  /* send names of layer in leafletvt group */
   var leafletvtViews = toObject(Object.keys(leafletvtId));
  // var leafletvtViews = toObject(Object.keys(this.layerManager._byGroup));
 
  Shiny.onInputChange("leafletvtViews",leafletvtViews);


};



