# leafletvt
[experimental] R leaflet support for mapbox vector tiles 

