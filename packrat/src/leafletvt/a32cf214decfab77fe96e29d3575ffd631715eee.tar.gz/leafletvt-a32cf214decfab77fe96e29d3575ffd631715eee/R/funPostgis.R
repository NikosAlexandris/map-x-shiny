
#' Transfert postgis feature by sql query to sp object
#' @param dbInfo Named list with dbName,host,port,user and password.
#' @param query PostGIS spatial sql querry.
#' @return spatial object.
#' @export
dbGetSp <- function(dbInfo,query) {
  if(!require('rgdal')|!require(RPostgreSQL))stop('missing rgdal or RPostgreSQL')
  d <- dbInfo
  tmpTbl <- sprintf('tmp_table_%s',round(runif(1)*1e5))
  dsn <- sprintf("PG:dbname='%s' host='%s' port='%s' user='%s' password='%s'",
    d$dbname,d$host,d$port,d$user,d$password
    )
  drv <- dbDriver("PostgreSQL")
  con <- dbConnect(drv, dbname=d$dbname, host=d$host, port=d$port,user=d$user, password=d$password)
  tryCatch({
    sql <- sprintf("CREATE UNLOGGED TABLE %s AS %s",tmpTbl,query)
    res <- dbSendQuery(con,sql)
    nr <- dbGetInfo(res)$rowsAffected
    if(nr<1){
      warning('There is no feature returned.'); 
      return()
    }
    sql <- sprintf("SELECT f_geometry_column from geometry_columns WHERE f_table_name='%s'",tmpTbl) 
    geo <- dbGetQuery(con,sql)
    if(length(geo)>1){
      tname <- sprintf("%s(%s)",tmpTbl,geo$f_geometry_column[1])
    }else{
      tname <- tmpTbl;
    }
    out <- readOGR(dsn,tname)
    return(out)
  },finally={
    sql <- sprintf("DROP TABLE %s",tmpTbl)
    dbSendQuery(con,sql)
    dbClearResult(dbListResults(con)[[1]])
    dbDisconnect(con)
  })
}


#' Geojson from postGIS base
#' @param dbInfo Named list with dbName,host,port,user and password
#' @param query PostGIS spatial sql querry.
#' @return geojson list
#' @export
dbGetGeoJSON<-function(dbInfo,query,fromSrid="4326",toSrid="4326"){
  # NOTE: check package geojsonio for topojson and geojson handling.
  # https://github.com/ropensci/geojsonio/issues/61
  d <- dbInfo
  dsn <- sprintf("PG:dbname='%s' host='%s' port='%s' user='%s' password='%s'",
    d$dbname,d$host,d$port,d$user,d$password
    )
  tmp <- paste0(tempfile(),".geojson")
  print(tmp)
  system(sprintf("ogr2ogr -f GeoJSON '%s' '%s' -sql '%s' -s_srs 'EPSG:%4$i' -t_srs 'EPSG:%5$i'",tmp,dsn,query,fromSrid,toSrid))
  return(jsonlite::fromJSON(tmp))
}
#' Get layer extent
#' @param dbInfo Named list with dbName,host,port,user and password
#' @param table Table/layer from which extract extent
#' @param geomColumn set geometry column
#' @return extent
#' @export
dbGetLayerExtent<-function(dbInfo=NULL,table=NULL,geomColumn='geom'){
  if(is.null(dbInfo) || is.null(table)) stop('Missing arguments')
  d <- dbInfo
  tryCatch({
    drv <- dbDriver("PostgreSQL")
    con <- dbConnect(drv, dbname=d$dbname, host=d$host, port=d$port,user=d$user, password=d$password)
    if(table %in% dbListTables(con)){
      ext<-dbGetQuery(con,sprintf("SELECT ST_Extent(%s) as table_extent FROM %s;",geomColumn,table))[[1]] %>%
      strsplit(split=",")%>%
      unlist()%>%
      gsub("[a-z,A-Z]|\\(|\\)","",.)%>%
      strsplit(split="\\s")%>%
      unlist()%>%
      as.numeric()%>%
      as.list()
      names(ext)<-c("lng1","lat1","lng2","lat2")
      return(ext)
    }
  },finally={
    dbDisconnect(con)
  })
  # return(ext)
}


#' @export
dbGetValByCoord <- function(dbInfo=NULL,table=NULL,column=NULL,lat=NULL,lng=NULL,geomColumn="geom",srid="4326",distKm=1){
  if(
    noDataCheck(dbInfo) ||
    noDataCheck(table) || 
    noDataCheck(column) || 
    noDataCheck(lat) ||
    noDataCheck(lng) ||
    isTRUE(column=='gid')
    ){
    return()
  }else{
    tryCatch({
      timing<-system.time({
        d=dbInfo
        drv <- dbDriver("PostgreSQL")
        con <- dbConnect(drv, dbname=d$dbname, host=d$host, port=d$port,user=d$user, password=d$password)

        
      # sqlPoint<-sprintf("ST_SetSRID(ST_MakePoint(%s, %s),%s)",lat,lng,srid)

        sqlPoint <- sprintf("'SRID=%s;POINT(%s %s)'",srid,lng,lat)


        sqlWhere <- sprintf(
          paste(
            "with index_query as (select st_distance(%s, %s) as distance, %s from %s order by %s <#> %s limit 10)",
            "select %s from index_query where distance < 0.1 order by distance limit 1;"
            ),
          geomColumn,sqlPoint,column,table,geomColumn,sqlPoint,column
          )


        res <- dbGetQuery(con,sqlWhere)
      })
       return(
          list(
            result=res,
            latitude=lat,
            longitude=lng,
            timing=timing
            )
          ) 
    },finally={
      dbDisconnect(con)
    })
  }
}




#' Get variable summary
#'
#' @param dbInfo Named list with dbName,host,port, user and password
#' @param table Table/layer from which extract extent
#' @param column Column/Variable on wich extract summary
#' @export
  dbGetColumnInfo<-function(dbInfo=NULL,table=NULL,column=NULL){
    if(noDataCheck(dbInfo) || noDataCheck(table) || noDataCheck(column) || isTRUE(column=='gid'))return() 
    d=dbInfo
    tryCatch({
      timing<-system.time({
      drv <- dbDriver("PostgreSQL")
      con <- dbConnect(drv, dbname=d$dbname, host=d$host, port=d$port,user=d$user, password=d$password)

      columnExists <- nrow(
        dbGetQuery(
          con,sprintf(
            "SELECT attname FROM pg_attribute WHERE attrelid = (SELECT oid FROM pg_class WHERE relname = '%s') AND attname = '%s';",
            table,column)
          )
        ) > 0

      if(!columnExists){
        message(paste("column",column," does not exist in ",table))
          return()
      }

      nR <- dbGetQuery(con,sprintf("SELECT count(*) FROM %s WHERE %s IS NOT NULL",table,column))[[1]]

      nN <- dbGetQuery(con,sprintf("SELECT count(*) FROM %s WHERE %s IS NULL",table,column))[[1]]
      nD <- dbGetQuery(con,sprintf("SELECT COUNT(DISTINCT(%s)) FROM %s WHERE %s IS NOT NULL",column,table,column))[[1]]
      val <- dbGetQuery(con,sprintf("SELECT DISTINCT(%s) FROM %s WHERE %s IS NOT NULL",column,table,column),stringAsFactors=T)[[1]]
      })


      scaleType <- ifelse(is.factor(val) || is.character(val),'discrete','continuous')
     
      return(list(
          'table' = table,
          'column' = column,
          'nDistinct'=nD,
          'nRow'=nR,
          'nNa'=nN,
          'scaleType'=scaleType,
          'dValues'=val,
          'timing'=timing
          )) 
    },finally={
      dbDisconnect(con)
    })
  }


