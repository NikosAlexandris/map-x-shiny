# leafletvt
[experimental] R leaflet support for mapbox vector tiles from PGRestAPI or MapBox 

