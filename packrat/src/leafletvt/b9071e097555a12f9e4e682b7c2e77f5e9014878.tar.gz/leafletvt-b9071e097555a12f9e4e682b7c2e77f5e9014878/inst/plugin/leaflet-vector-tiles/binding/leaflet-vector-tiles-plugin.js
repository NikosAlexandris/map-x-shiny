


function randomHsl(opacity) {
  var col = 'hsla(' + (Math.random() * 360) + ', 100%, 50%, '+ opacity +')';
  return col;
}




function hex2rgb(hex, opacity) {
  var h=hex.replace('#', '');
  h =  h.match(new RegExp('(.{'+h.length/3+'})', 'g'));

  for(var i=0; i<h.length; i++)
    h[i] = parseInt(h[i].length==1? h[i]+h[i]:h[i], 16);

  if (typeof opacity != 'undefined')  h.push(opacity);

  return 'rgba('+h.join(',')+')';
      }



  //http://stackoverflow.com/questions/5623838/rgb-to-hex-and-hex-to-rgb
/*
function hexToRgbA(hex,alpha) {
  var bigint = parseInt(hex, 16);
  var r = (bigint >> 16) & 255;
  var g = (bigint >> 8) & 255;
  var b = bigint & 255;

  var col="rgba(" + r + "," + g + "," + b + "," + alpha + ")" ;
      console.log(col);
      return(col);

}
*/


var tmpLayer ;

LeafletWidget.methods.addVectorTiles = function(urlTemplate,vectLayer,idColumn,dataColumn,layerId,opacity,valueColor) {
  var config = {
    url:urlTemplate,
    debug: false,
    clickableLayers: [vectLayer],
    getIDForLayerFeature: function(feature) {
      //console.log(feature);
      return feature.properties[idColumn];

    },
    filter: function(feature, context) {
      if (feature.layer.name === vectLayer) {
        return true;
      }
      return false;
    },
    style: function (feature) {
      var style = {};
      var type = feature.type;
      var dataCol = hex2rgb(valueColor[feature.properties[dataColumn]],opacity);
      
 console.log(dataCol);
      switch (type) {
        case 1: //'Point'
          style.color = 'rgba(49,79,79,1)';
          style.radius = 5;
          style.selected = {
            color: 'rgba(255,255,0,0.5)',
            radius: 6
          };
          break;
        case 2: //'LineString'
          style.color = 'rgba(161,217,155,0.8)';
          style.size = 3;
          style.selected = {
            color: 'rgba(255,25,0,0.5)',
            size: 4
          };
          break;
        case 3: //'Polygon'
         /*  var pop=parseInt(feature.properties.pop2005);
             var cntry=feature.properties.iso2;
             console.log(cntry+":"+pop); 

             if(pop>7e6){
             style.color = 'rgba(30,30,30,0.4)';
             }else{
             style.color = 'rgba(0,255,0,0.1)';
             };
             */
          //style.color = fillColor;
          //var colRand = randomHsl(opacity);
          style.color = dataCol;
          style.outline = {
            color: dataCol,
            size: 1
          };
          style.selected = {
            color: 'rgba(255,140,0,0.3)',
            outline: {
              color: 'rgba(255,140,0,1)',
              size: 2
            }
          };
          break;
      }
    

           
      return style;
    }
  };

  if(typeof(tmpLayer) != "undefined"){
    this.removeLayer(tmpLayer);
  }


  var mvtSource = new L.TileLayer.MVTSource(config);

  tmpLayer = mvtSource;

  this.addLayer(mvtSource);


};

