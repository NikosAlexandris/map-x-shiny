leafletVectorTilesDependencies <- function() {
  list(
    htmltools::htmlDependency(
      "leaflet-vector-tiles-lib",
      "0.1.5",
      system.file("plugin/leaflet-vector-tiles/lib/dist/", package = "leafletvt"),
      script = "Leaflet.MapboxVectorTile.min.js"
    ),
    htmltools::htmlDependency(
      "leaflet-vector-tiles-binding",
      packageVersion("leafletvt"),
      system.file("plugin/leaflet-vector-tiles/binding/", package = "leafletvt"),
      script = "leaflet-vector-tiles-plugin.js"
    )
  )
}




#' Add vector tiles for a given PGRestAPI postgres endpoint.
#' @param map Leaflet map object
#' @param urlTemplate Url template for a givent PGRestAPI endpoint.
#' @export
addVectorTiles <- function(
  map,
  url="localhost",
  port=3030,
  table=NULL,
  dataColumn=NULL,
  geomColumn="geom", # should be auto resolved by PGRestAPI
  idColumn="gid", # should be auto resolved by PGRrestAPI
  colorFunction=NULL,
  layerId ='vectortileslayer',
  opacity=0.5,
  valueColor=NULL
  #options = providerTileOptions()
) {
  layer <- paste0(table,"_",geomColumn)
  cols=c(idColumn,dataColumn)
  cols <- sprintf("?fields=%s",paste(cols,collapse=",")) 
  url<-sprintf("http://%s:%s/services/postgis/%s/%s/vector-tiles/{z}/{x}/{y}.pbf%s",url,port,table,geomColumn,cols)
  map$dependencies <- c(map$dependencies, leafletVectorTilesDependencies())
  invokeMethod(map,getMapData(map),'addVectorTiles',url,layer,idColumn,dataColumn,layerId,opacity,valueColor)
}

#
#providerTileOptions <- function(errorTileUrl = '', noWrap = FALSE,
#  opacity = NULL, zIndex = NULL, unloadInvisibleTiles = NULL,
#  updateWhenIdle = NULL, detectRetina = FALSE, reuseTiles = FALSE, ...
#) {
#  opts <- list(errorTileUrl = errorTileUrl, noWrap = noWrap,
#    zIndex = zIndex, unloadInvisibleTiles = unloadInvisibleTiles,
#    updateWhenIdle = updateWhenIdle, detectRetina = detectRetina,
#    reuseTiles = reuseTiles, ...)
#  # Don't include opacity=NULL--it overrides the provider's default opacity
#  if (!is.null(opacity))
#    opts$opacity <- opacity
#  opts
#}
