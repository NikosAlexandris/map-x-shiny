# jed : r interface for jsoneditor

[ experimental ] implementation of jdorn/json-editor in shiny
