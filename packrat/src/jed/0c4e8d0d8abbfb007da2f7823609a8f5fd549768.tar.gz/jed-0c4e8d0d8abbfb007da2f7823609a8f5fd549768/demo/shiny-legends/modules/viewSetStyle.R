library(shiny)
library(jed)


#
# UI
#

module_viewStyleUi <- function(id){
  ns <- NS(id)

  tagList(
    includeCSS("www/css/legends.css"),
    tags$div(class="col-md-8",
      jedOutput(ns("jed"))
      ),
    tags$div(class="col-md-3",
      uiOutput(ns("legends"))
      )
    )
}


#
# SERVER
#

module_viewStyleServer <- function(
  input, 
  output, 
  session, 
  obj
  ) {

  #
  # REACTIVE
  #
  react <- reactiveValues()
  #
  # Render schema
  #
  output$jed <- jedRender({
cat(obj$reset)
    jedSchema(
      list(
        schema = makeShemaViewStyle(obj$values),
        startval = obj$oldStyle
        )
      )
  })


  #
  # make legend
  #

  observe({
    react$val <- jedGetValues("jed")
  })

  output$legends <- renderUI({

    makeLegend(
      styleList = react$val,
      spritePng = "sprite/sprites.png",
      spriteJson = "www/sprite/sprites.json"
      )
  })

  #
  # Return values
  #
  return(react)
}

#
# HELPERS
#



hex2rgba <- function(x,opacity=1){
  r <- strtoi(sprintf("0x%s",substr(x,2,3)))
  g <- strtoi(sprintf("0x%s",substr(x,4,5)))
  b <- strtoi(sprintf("0x%s",substr(x,6,7)))
  a <- round(opacity*255)
  sprintf("rgba(%s,%s,%s,%s)",r,g,b,a)
}




makeLegend <- function(styleList,spritePng,spriteJson,defaultBoxWidth=20,defaultBoxHeight=20){

  if(
    ! is.list(styleList) ||
      ! all(names(styleList) %in% c("name","description","type","style"))
    ) return()

  values <- list()
  sprites <- list()
  sprites$json <- jsonlite::fromJSON(spriteJson)
  sprites$png <- spritePng
  sprites$x <- sapply(sprites$json,function(x){x$x})
  sprites$y <- sapply(sprites$json,function(x){x$y})
  sprites$w <- sapply(sprites$json,function(x){x$width})
  sprites$h <- sapply(sprites$json,function(x){x$height})


  style <- styleList$style
  title <- styleList$name

  if(length(style)>0){
    for( i in 1:length(style)){
      sprite <- style[[i]]$sprite
      value <- style[[i]]$value
      label <- style[[i]]$label

      if(length(label) < 1 || label == ""){
        label <- value 
      }

      values[[i]] <- sprintf(
        "<li class='mx-legend '>
        <div style='
        background-color:%1$s;
        background-image:url(\"%2$s\");
          background-position: %3$s;
          float: left;
          margin: 0px 10px 0px 0px;
          width: %4$spx;
          height: %5$spx;
          '></div>
          %6$s
          </li>",
          hex2rgba(style[[i]]$color,style[[i]]$opacity),
          if( sprite != "none"){
            sprites$png 
          }else{
            ""
          },
          if( sprite != "none"){ 
            sprintf("-%1$spx -%2$spx",
              sprites$x[ sprite ],
              sprites$y[ sprite]
              ) 
          }else{ 
            ""
          },
          if( sprite != "none"){
            w <- sprites$w[ sprite ]
            if(w < defaultBoxHeight){
              w
            }else{
              defaultBoxHeight 
            }
          }else{
            defaultBoxWidth
          },
          if( sprite != "none"){
            h <- sprites$h[ sprite ]
            if(h < defaultBoxHeight){
              h
            }else{
              defaultBoxHeight 
            }
          }else{
            defaultBoxHeight
          },
          label
          )
    }
  }
  out <- tags$div(class="mx-legend ",
    tags$h5(title),
    tags$ul(HTML(paste(values)))
    )

  return(out)

}

makeShemaViewStyle <- function(values){

    if( 
      isTRUE( is.null( values ) ) || 
      isTRUE( length( values ) <1 )  ||
      isTRUE( ! is.vector( values ) )
    ) return( list() )

    if( mode(values) == "numeric" ){
      valType = "number"
    }else{
      valType = "string"
    }

    list(
      title = "View",
      type = "object",
      properties  = list(
        name = list(
          title = "View name",
          type = "string",
          default = "View name",
          minLength = 5
          ),
        description = list(
          title = "Description",
          type = "string",
          format = "markdown",
          default = "Description",
          minLength = 5
          ),
        type = list(
          title = "Type",
          type = "string",
          enum = c("polygon","symbol","line")
          ),
        style = list(
          title = "Style",
          type = "array",
          format = "table",
          items = list(
            type = "object",
            title = "Rule",
            properties = list(
              operator = list(
                title = "Operator",
                type = "string",
                input_width="100px",
                enum = c(
                  "==",
                  ">=",
                  "<=",
                  "!=",
                  "<",
                  ">",
                  "in",
                  "!in"
                  ),
                default="=="
                ),
              value = list(
                title = "Value",
                type = valType,
                enum = unique(values),
                minLength=1
                ),
              label = list(
                title = "Label",
                type = "string"
                ),
              color = list(
                title = "Background",
                type = "string",
                format = "color",
                default = "#f1f3d7"
                ),
              opacity = list(
                title = "Opacity",
                type = "number",
                enum = c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1),
                default = 1
                ),
              sprite = list(
                title = "Symbol",
                type = "string",
                enum = c("none",names(jsonlite::fromJSON("www/sprite/sprites.json")))
                )
              )
            )
          )
        )
      )
  }


