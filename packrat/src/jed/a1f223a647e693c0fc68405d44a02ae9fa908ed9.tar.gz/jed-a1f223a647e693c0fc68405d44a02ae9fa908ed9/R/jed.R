#' Create schema
#'
#' Create html form element using a named list
#'
#' @import htmlwidgets
#'
#' @export
jedSchema <- function(options = list(), width = NULL, height = NULL) {

  stopifnot(is.list(options))


  # create widget
  htmlwidgets::createWidget(
    name = 'jed',
    options,
    package = 'jed',
    width = width,
    height = height
    )
}

#' Shiny bindings for jed
#'
#' Output and render functions for using jed within Shiny  applications and interactive Rmd documents.
#'
#' @param outputId output variable to read from
#' @param expr An expression that generates a jed
#' @param env The environment in which to evaluate \code{expr}.
#' @param values  List of values to update according to the schema
#' @param quoted Is \code{expr} a quoted expression (with \code{quote()})? This
#'   is useful if you want to save an expression in a variable.
#'
#' @name jed-shiny
#'
#' @export
jedOutput <- function(outputId,width = "100%", height = "100%"){
  tags$div(class="jed-container",
    htmlwidgets::shinyWidgetOutput(outputId, 'jed', width, height, package = 'jed')
    )
}

#' @rdname jed-shiny
#' @export
jedRender <- function(expr, env = parent.frame(), quoted = FALSE) {
  if (!quoted) { expr <- substitute(expr) } # force quoted
  htmlwidgets::shinyRenderWidget(expr, jedOutput, env, quoted = TRUE)
}


#' @rdname jed-shiny
#' @export 
jedGetValues <- function(editorId=NULL,session=shiny::getDefaultReactiveDomain()){
    session$input[[sprintf("%s_values",editorId)]]
}
#' @rdname jed-shiny
#' @export 
jedGetIssues <- function(editorId=NULL,session=shiny::getDefaultReactiveDomain()){
    session$input[[sprintf("%s_issues",editorId)]]
}

#' @rdname jed-shiny
#' @export 
jedUpdate <- function(editorId = NULL, values = list(), session=shiny::getDefaultReactiveDomain() ){

  session$sendCustomMessage(
    type="updateJed",
    list(
      id = editorId ,
      val = values 
      )
    )

}
