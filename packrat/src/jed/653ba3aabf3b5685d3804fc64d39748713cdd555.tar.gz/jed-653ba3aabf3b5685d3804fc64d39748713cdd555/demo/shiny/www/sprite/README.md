

Sprites generated using mapbox [spritezero-cli](https://github.com/mapbox/spritezero-cli)

Using glyphicons from [smaritons.co](http://glyph.smarticons.co)


