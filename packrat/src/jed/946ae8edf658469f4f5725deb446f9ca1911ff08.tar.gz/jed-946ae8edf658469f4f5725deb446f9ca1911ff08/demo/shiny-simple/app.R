library(shiny)
library(jed)



mySchema = list(
  title = "Person",
  type = "object",
  properties = list(
    name = list(
      type = "string",
      title = "Username",
      minLength = 4,
      default = "Jack-the-ripper"
      ),
    colors = list(
      type = "array",
      format = "table",
      items = list(
        title = "Color",
        default = "#000",
        type = "string",
        format="color"
        )
      )
    )
  )


ui <- shinyUI(fluidPage(
    titlePanel(textOutput("title")),
    sidebarLayout(
      sidebarPanel(
        jedOutput("test")
        ),
      mainPanel(
        textInput("textInput",label="Edit",value=""),
        actionButton("updateJed",label="Update jed")
        )
      )
    )
  ) 


server <- function(input,output,session){
  output$test <- jedRender({
    jedSchema(
      option=list(
        schema=mySchema
        )
      )
  })


  output$title <- renderText({
      name <- input$test_values$name
      sprintf("Hello %s",name)
  })


  observe({
  updateTextInput(
    session,
    inputId="textInput",
    value=as.character(jsonlite::toJSON(input$test_values,auto_unbox=T))
    )
  })


  output$textInput <- renderText({
    values <- input$test_values
    jsonlite::toJSON(values,auto_unbox=T)
  })
  

  observeEvent(input$updateJed,{
   val <- jsonlite::fromJSON(input$textInput,simplifyVector=FALSE)
   jedUpdate(
     editorId="test",
     value=val
     )
  })

}


shinyApp(ui=ui,server=server)
