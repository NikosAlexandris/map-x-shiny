library(shiny)

source("modules/viewSetStyle.R")

styleFile <- "www/style/sample.json"
user <- "james"
group <- c("public","creator")
viewId <- "View name"
layer <- "test"
variable <- "concessions"
react <- reactiveValues()
react$values <- c(1,2,3,4,5)
react$oldStyle <- jsonlite::fromJSON(styleFile,simplifyVector=F)


sources <- list()


sources$layer <- list()



sources$layer <- c("cod__test_1","afg__test_2")
sources$views <- c("a","b")


ui <- fixedPage(
  h2("View style settings"),
  checkboxInput("allow","AllowUi",value=TRUE),
  uiOutput("demoViewDyn")
  )

server <- function(input,output,session){

  viewStyle <- callModule(
    module = module_viewStyleServer,
    id = "demoView",
    obj = react
    )



  output$demoViewDyn <- renderUI({
    if(input$allow){
      tagList(
        tags$div(class="btn-group",role="group",`aria-label`="...",
          actionButton("btnViewSave","Save"),
          actionButton("btnViewCompute","Compute"),
          actionButton("btnViewReset","Reset")
          ),
        module_viewStyleUi("demoView")
        )
    }else{
      tags$p("restricted")
    }
  })

  observeEvent(input$btnViewReset,{
    react$reset = runif(1)
  })


  observeEvent(input$btnViewCompute,{
  viewStyle$val
  browser()
  })


  observeEvent(input$btnViewPublish,{
    write(jsonlite::toJSON(viewStyle$val,auto_unbox=T),styleFile)
    react$oldStyle <- jsonlite::fromJSON(styleFile,simplifyVector=F)
  })


}
shinyApp(ui = ui, server = server)






