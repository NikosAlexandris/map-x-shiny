library(testthat)
library(longurl)

test_check("longurl")
